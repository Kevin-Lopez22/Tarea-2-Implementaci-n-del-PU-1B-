package Clases;

public class Administrador {
	//Atributos
    private String nombreAdmin;
    private int CIAdmin;

    public Administrador(String nombreAdmin, int CIAdmin) {
        this.nombreAdmin = nombreAdmin;
        this.CIAdmin = CIAdmin;
    }
    
    //Método
    public void ingresarDatos(){};

}
