package Clases;

import Interfaces.GestorCitas;

public class Main {
	//Métodos
    public static void EjecutarGestorCitas(){
        GestorCitas g1 = new GestorCitas();
        g1.setVisible(true);
    }
    
    public static void SolicitarEliminacion(){};
    
    
    public static void main(String[] args){
        EjecutarGestorCitas();
    }
}
