package Interfaces;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GestorCitas extends JFrame {

	private JPanel contentPane;
	InterfazAgendar Iagendar = new InterfazAgendar();
    InterfazEliminar Ieliminar = new InterfazEliminar();

	/**
	 * Create the frame.
	 */
	public GestorCitas() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 153);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("CONCESIONARIO DE AUTOS");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 20));
		
		JButton btnAgendarCita = new JButton("Agendar Cita");
		btnAgendarCita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				this.SolicitarAgendamiento();
			}

			private void SolicitarAgendamiento() {
				Iagendar.setVisible(true);
				
			}
		});
		btnAgendarCita.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JButton btnEliminarCita = new JButton("Eliminar Cita");
		btnEliminarCita.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEliminarCita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				this.SolicitarEliminacion();
			}

			private void SolicitarEliminacion() {
				Ieliminar.setVisible(true);
				
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(87)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 333, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(256, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(28)
					.addComponent(btnAgendarCita)
					.addPreferredGap(ComponentPlacement.RELATED, 209, Short.MAX_VALUE)
					.addComponent(btnEliminarCita)
					.addGap(29))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAgendarCita)
						.addComponent(btnEliminarCita))
					.addGap(395))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
