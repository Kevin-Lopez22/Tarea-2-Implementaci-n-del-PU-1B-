package Interfaces;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import net.miginfocom.swing.MigLayout;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InterfazEliminar extends JFrame {

	private JPanel contentPane;
	
	//Atributos
    private int citaID;
    JTextArea txtAInformacion;

  //Metodos
    File respaldo;
    private JTextField txtID;
    public void solicitarDatos(){
        JOptionPane.showMessageDialog(null, "Ingrese cuidadosamente los datos requeridos para eliminar la cita");
    }
    
    public void EliminarCita(int citaID){
        String nombre = "C:\\Users\\JAVIER\\Desktop\\CitaID" + citaID+".txt";
        try{
            File archivo= new File(nombre);
            if(archivo.delete()){
               txtAInformacion.setText("Cita eliminada exitosamente");
            }
        }catch(Exception e){
            
        }
    }
    
    public boolean ComprobarExistencia(int citaID){
        
    //Busqueda del archivo 
        String nombre = "C:\\Users\\JAVIER\\Desktop\\CitaID" + citaID+".txt";
            
            File archivo;
            FileReader fr;
            BufferedReader br;
            
        try{
            archivo= new File(nombre);
            if(archivo.exists()){
            return true;
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se encontró registros para la cita especificada");
        }
        
        return false;
    }
    
    public void VolverAGestorCitas(){
        this.setVisible(false);
    }
    

	/**
	 * Create the frame.
	 */
	public InterfazEliminar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 364, 317);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("ELIMINAR CITA");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		JLabel lblNewLabel_1 = new JLabel("Información Cita");
		
		JLabel lblNewLabel_2 = new JLabel("Cita ID");
		
		txtID = new JTextField();
		txtID.setColumns(10);
		
		txtAInformacion = new JTextArea();
		
		JButton btnNewButton = new JButton("Eliminar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				citaID = Integer.parseInt(txtID.getText());
		        if(ComprobarExistencia(citaID))
		        {
		            EliminarCita(citaID);
		            txtAInformacion.setText("La cita se eliminó de manera correcta");
		        }else{
		            txtAInformacion.setText("Error: La cita ingresada no existe");
		        }
			}
		});
		
		JButton btnNewButton_1 = new JButton("Volver");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(txtAInformacion, GroupLayout.PREFERRED_SIZE, 323, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 313, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(txtID, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)))
							.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton)
							.addGap(50)
							.addComponent(btnNewButton_1)
							.addGap(77))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(txtID, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(txtAInformacion, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		
	}
}
